This is a timer Cinnamon applet.

## Requirements
This applet requires (optional):

> sox package (to play sounds);
> zenity package (to show system notifications).

## Installation
Download and enable via Cinnamon Settings.

