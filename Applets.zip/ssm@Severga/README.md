This is a simplified Cinnamon applet that provides information about system load and state (CPUs, memory, network).

## Requirements
This applet requires:

> gtop system monitoring library package;
> 'lm-sensors' package (for CPU temperature monitoring);
> NetworkManager;
> gnome-system-monitor (is opened on click).

## Installation
Download and enable via Cinnamon Settings.

